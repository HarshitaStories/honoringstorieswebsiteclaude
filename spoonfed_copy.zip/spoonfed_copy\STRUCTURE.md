# Structure: what every file is, and what depends on what

---

## 1. The folder tree

```
website/                                  <-- publish the CONTENTS of this folder
│
├── index.html                            Homepage
├── about.html                            About Harshita
├── psychotherapy.html                    Psychotherapy sessions
├── supervision.html                      Supervision sessions
├── corporates.html                       Workplace Wellbeing, for organisations
├── community.html                        Community
├── disclaimer.html                       Legal
├── privacy-policy.html                   Legal
├── terms-and-conditions.html             Legal
│
├── serve.ps1                             Local viewing helper. NOT part of the website.
│
└── assets/                               Every picture
    ├── logo.png                          Nav logo and browser tab icon. Used by all 9 pages.
    ├── Whitelogo.png                     Footer logo. Used by all 9 pages.
    ├── harshita-home.png                 Homepage main photo
    ├── harshita-glimpse.png              Homepage second photo
    ├── therapy-hero.jpg                  Psychotherapy page illustration
    ├── supervision-hero.jpg              Supervision page illustration
    ├── workplace-wellbeing.png           Organisations page illustration
    ├── harshita-organisations.jpg        Organisations page round portrait
    ├── community-hero.jpg                Community page top banner
    ├── sharedwaysofcoping.jpg            Community page section illustration
    │
    ├── harshita-chair.jpg                KEPT BUT UNUSED. Previous homepage photo.
    ├── harshita-home-source.png          KEPT BUT UNUSED. Original before editing.
    ├── harshita-home 2.png               KEPT BUT UNUSED. Older photo. Note the space in the name.
    └── logo-full.png                     KEPT BUT UNUSED. Older colour logo.
```

**The four marked KEPT BUT UNUSED are not rubbish.** They are kept on purpose in case an earlier
version of a picture is wanted back. Do not delete them without asking.

---

## 2. Parent and child: how the pages relate

There is no technical parent and child here; every page is an equal, standalone file. But there is
a **navigational** hierarchy, which is what visitors experience, and it is what the menu expresses.

```
index.html  (Home)
│
├── about.html                                  "About" in the menu
│
├── Work With Me      (a menu heading only, not a page of its own)
│   ├── psychotherapy.html                      "Psychotherapy sessions"
│   ├── supervision.html                        "Supervision sessions"
│   └── corporates.html                         "Workplace Wellbeing"
│
├── community.html                              "Community" in the menu
│
└── Footer only, not in the top menu
    ├── disclaimer.html
    ├── privacy-policy.html
    └── terms-and-conditions.html
```

**"Work With Me" is not a page.** It is a heading in the menu that opens a small dropdown holding
the three pages beneath it. Clicking the words themselves does nothing on purpose. If you ever see
it behaving like a link, that is a fault.

### An important point about linking

Although the hierarchy above is what a visitor perceives, **every page links to every other page**,
because all nine carry the same menu and the same footer. There is no page you can only reach from
one place. Confirmed: all nine pages link to all nine.

This is why Rule 2 in the README matters so much. The menu is not "on the homepage". It is on all
nine pages, nine separate times.

---

## 3. Inside a single page file

Every page has the same skeleton. Open any of them in a text editor and you will find, in order:

```
<!DOCTYPE html>
<html>
  <head>
      title, description, tab icon
      the Google Fonts link                <-- the only outside stylesheet
      <style>  ... ALL THE CSS FOR THIS PAGE ...  </style>
  </head>
  <body>
      the top menu           (identical on all 9 pages)
      the mobile menu        (identical on all 9 pages)
      the dots down the right edge   (page specific)
      the page banner
      ... the page's own sections ...
      the contact strip
      the footer             (identical on all 9 pages)
      the floating WhatsApp button   (identical on all 9 pages)
      <script>  ... ALL THE JAVASCRIPT FOR THIS PAGE ...  </script>
  </body>
</html>
```

The four blocks marked "identical on all 9 pages" are the shared furniture. They are copied, not
shared. That is the trade-off described in the README.

---

## 4. The sections inside each page

These names are the anchors used by the little dots down the right-hand edge of the screen.

| Page | Sections, in order |
| --- | --- |
| `index.html` | values, concerns, glimpse, testimonials, work-with-me, contact |
| `about.html` | bio, values, qualifications, experience, contact |
| `psychotherapy.html` | who, logistics, pricing, process, faqs, contact |
| `supervision.html` | who, logistics, pricing, process, faqs, contact |
| `corporates.html` | why, offer, themes, how, about-me, faqs, contact |
| `community.html` | shared-ways, sip-and-swap, how, contact |
| The three legal pages | Plain text, no sections and no dots |

Psychotherapy and Supervision are deliberately built to the same shape. If you change the structure
of one, the other usually needs the same change so they stay recognisably a pair.

---

## 5. What depends on what

Use this before changing anything, to see what else you will have to touch.

| If you change this | You must also touch |
| --- | --- |
| The top menu | All 9 page files, twice each: the desktop menu and the mobile menu |
| The footer | All 9 page files |
| The floating WhatsApp button | All 9 page files |
| Any colour in the palette | All 9 page files, in the `:root` block at the top of each `<style>` |
| The booking link | All 9 page files, 33 buttons in total |
| The email or WhatsApp number | All 9 page files |
| A picture's filename | Every page that shows it, see the tree in section 1 |
| The Google Form questions | `community.html`, the two `entry.` numbers. See SETUP_CHECKLIST item 4 |
| The Approved sheet formula | Nothing in the code, but notes stop appearing if it breaks |
| The psychotherapy page layout | Usually the supervision page too, to keep them a matching pair |

---

## 6. The moving parts, and which page each lives on

| What it does | Page | Notes |
| --- | --- | --- |
| Mobile menu open and close | all 9 | |
| Scroll animations, things fading in | all 9 | Switched off automatically for anyone whose device asks for reduced motion |
| The dots down the right edge highlighting as you scroll | 6 | Not on the legal pages |
| Numbers counting up | `index.html` | In the glimpse section |
| Testimonials sliding | `index.html` | 8 real testimonials, used with permission |
| FAQ questions opening | psychotherapy, supervision, corporates | |
| Price changing by country | psychotherapy, supervision | Explained below |
| Confidentiality panel expanding | `corporates.html` | |
| Word counter counting down from 100 | `community.html` | |
| Sending a coping note | `community.html` | |
| Reading approved notes | `community.html` | The only thing that fetches from outside while a visitor is on the page |

### About the price changing by country

Visitors in India see one online price; visitors elsewhere see another. The two are never shown
together.

It works out where the visitor is by reading **their computer's own timezone setting**, which the
browser already knows. It does **not** look up their internet address.

**This was a deliberate privacy decision.** Looking up the internet address would mean sending every
single visitor's IP address to some other company, and the Privacy Policy on this same website says
there is no tracking beyond Google Fonts. That statement had to stay true.

The trade-off is that someone travelling, or using a VPN, sees the price for wherever their computer
thinks it is. That was judged acceptable.

---

## 7. Things that go outside the website

Four, and only four.

| What | Purpose | If it stops working |
| --- | --- | --- |
| Google Fonts | The two typefaces | Text falls back to plain system fonts. Everything still readable |
| cal.com | The booking button | Booking buttons go nowhere |
| Google Forms | Sending a coping note | The submission box stops accepting notes |
| Google Sheets | Reading approved notes | Notes stop appearing. The page shows a polite message instead of breaking |

Everything else is inside the folder. There is no database, no login system, no analytics, no
advertising trackers, and no cookie banner, because there is nothing that would need one.

---

## 8. The nine files, at a glance

| File | Size | What it is for |
| --- | --- | --- |
| `index.html` | 79 KB | The homepage. The largest file, because it holds the testimonials and the counting numbers |
| `community.html` | 60 KB | Community. Second largest, because of the note submission and reading code |
| `psychotherapy.html` | 58 KB | Psychotherapy sessions |
| `corporates.html` | 55 KB | Workplace Wellbeing |
| `supervision.html` | 54 KB | Supervision sessions |
| `about.html` | 46 KB | About Harshita |
| `privacy-policy.html` | 41 KB | Legal |
| `terms-and-conditions.html` | 40 KB | Legal |
| `disclaimer.html` | 38 KB | Legal |

The files look large for what they are because each one carries its own complete copy of the
styling. That is expected, not a problem to be fixed.
