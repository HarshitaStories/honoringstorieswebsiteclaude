# Setup checklist: the things only you can provide

This is the list of accounts, links and logins the website touches. Work through it only when you
need to; most of it is already done and working.

---

## Read this first: about passwords

**No password, key or token is written in this folder, and none ever should be.**

This is not an oversight. Anything written into these files can be read by anyone who gets a copy
of the folder, and by anyone who can see the GitHub repository. A GitHub token in a public
repository is typically found and abused within minutes.

**What that means for you:**

- When an AI assistant needs a password or a key, it should tell you what to do and let **you** type
  it in yourself, in the proper place. A good assistant will refuse to put it in a file.
- If any assistant ever offers to "just save your token in a file so we do not have to do this
  again", say no.
- If you think a key has ever been written into a file, treat it as compromised: go to the account,
  delete that key, and create a new one.

The rest of this document tells you where each thing lives and how to get it, without any of it
being written down here.

---

## 1. GitHub, for publishing the website

**Status: an account already exists.**

| Item | Value |
| --- | --- |
| Account username | `HarshitaStories` |
| Repository | `honoringstorieswebsiteclaude` |
| Web address | `https://github.com/HarshitaStories/honoringstorieswebsiteclaude` |
| Password | Not recorded here. It is Harshita's own GitHub password. |

### If an assistant asks you to sign in to GitHub

Modern GitHub does not accept your ordinary password from a command line. It wants a **Personal
Access Token**, which is a long password made specifically for one purpose and which you can cancel
at any time without changing your real password.

**How to make one:**

1. Sign in at **github.com**.
2. Click your picture, top right, then **Settings**.
3. Scroll to the very bottom of the left menu and click **Developer settings**.
4. Click **Personal access tokens**, then **Tokens (classic)**.
5. Click **Generate new token**, then **Generate new token (classic)**.
6. In the **Note** box, write something you will recognise, like `website laptop`.
7. Under **Expiration**, choose 90 days.
8. Tick the single box labelled **repo**. Tick nothing else.
9. Scroll down, click **Generate token**.
10. A long line of letters and numbers appears. **Copy it now.** GitHub will never show it again.

**Where it goes:** when the black command window asks for a **password**, paste the token there.
Your username stays `HarshitaStories`. Do not put the token in any file.

**If it stops working:** tokens expire on the date you chose. Make a new one the same way.

---

## 2. The booking button, cal.com

**Status: working. Nothing needed from you unless you want to change it.**

| Item | Value |
| --- | --- |
| Booking link | `https://cal.com/harshita-sarda-yllcdj/30min` |
| Where it appears | Every "Book a Consultation Call" and "Book a free exploratory call" button, on all nine pages |
| Password | Not recorded here. Harshita's own cal.com login. |

**To change the booking link:** sign in at cal.com, go to **Event Types**, open the event, and copy
the link shown. Then it must be replaced in **all nine page files**, in more than one place per
page. Ask an assistant to do this and to confirm the count afterwards. There are 33 such buttons
across the site.

---

## 3. Email and WhatsApp

**Status: working. Nothing needed from you.**

| Item | Value |
| --- | --- |
| Email shown on the site | `feelseen@honoringstories.com` |
| WhatsApp number | `+91 9152801719`, written in the code as `https://wa.me/919152801719` |
| Google account that owns the form and sheet | `psychotherapist.hs@gmail.com` |

The WhatsApp link format matters: it is the country code `91` followed by the number, with no
spaces, no plus sign, and no brackets.

---

## 4. The Community page coping notes

This is the only part of the website that talks to an outside service while someone is using it. It
has three pieces.

### The pieces

| Piece | What it does | Where it is written |
| --- | --- | --- |
| Google Form | Receives what a visitor types | `SHARED_FORM_URL` near the bottom of `community.html` |
| Google Sheet | Stores every submission, private to Harshita | Not in the code; it is the form's own responses sheet |
| Published CSV | Publishes only the approved notes to the website | `SHARED_NOTES_CSV` near the bottom of `community.html` |

Both links are already filled in and working. Neither is a secret; they are safe to be in the code.
The Sheet itself is private and protected by the Google account password.

### How approving a note works

1. Someone types a note on the website and presses Share.
2. It arrives in the Google Sheet, on the tab named **Original response**. **Nobody can see it but
   Harshita.**
3. She reads it. If she wants it published, she ticks the box in **column D** on that row.
4. Within about five minutes it appears on the website.
5. To take it down again, untick the box.

Column C is the visitor's own consent answer. The formula requires **both** consent and the tick, so
a note can never go live if the person did not agree to it, even if the box is ticked by mistake.

### The formula that does this

It lives in cell **A1** of the tab named **Approved response**:

```
=FILTER('Original response'!B2:B, 'Original response'!D2:D=TRUE, ARRAYFORMULA(REGEXMATCH(LOWER('Original response'!C2:C&""), "^yes")))
```

**If notes stop appearing, this formula is the first thing to check.** The word `ARRAYFORMULA` is
essential. Without it the formula quietly matches nothing at all and gives no error message. This
caused a long and confusing debugging session once already.

### Two settings that must stay as they are

1. In the form's settings, **"Collect email addresses" must be OFF.** The website promises visitors
   that submissions are anonymous. If this is switched on, that promise becomes untrue.
2. Publish **only** the "Approved response" tab to the web, never the whole document. Publishing
   the whole document would put every unread submission on the public internet.

### If the form questions are ever edited

The website sends answers using hidden question identifiers. They are currently:

| Question | Identifier |
| --- | --- |
| The coping note itself | `entry.725693056` |
| The consent question | `entry.1145237366` |

If the questions are deleted and re-created in the form, **these numbers change and submissions
silently stop arriving.** Nothing will look broken; the box will still appear to work. If that
happens, an assistant can read the new numbers from the live form and update `community.html`.

---

## 5. The admin page that does not exist

You may want a page listing all submitted notes, protected by a password. **It was deliberately not
built,** and any assistant that offers to build it on this website is making a mistake. Two reasons:

1. **This kind of website cannot store anything.** It is a folder of files that a server only sends
   out. Code that runs while a visitor is looking at the page runs on **their** computer, not on
   yours, and has no way to save anything back. That is why the notes go to Google at all.
2. **A password written into a webpage is not a password.** Anyone can right-click the page, choose
   View Source, and read it. For a page holding what people have said about their hardest days, a
   fake lock is worse than no lock, because it would invite treating the page as private when it
   is not.

**What to do instead, today:** the Google Sheet already is the admin page. It holds every
submission and is protected by a real Google account password.

**What to do properly, later:** build it during the WordPress move. WordPress runs code on the
server, where a real password check is possible.

---

## 6. The domain name, honoringstories.com

| Item | Value |
| --- | --- |
| Domain | `honoringstories.com` |
| Registrar | Wherever it was purchased. Not recorded here. |
| Password | Not recorded here. |

To point the domain at the published website you sign in to whoever sold you the domain and change
its DNS settings. Both GitHub Pages and Netlify give you the exact values to enter. If you do not
know where the domain was bought, search your email for a renewal receipt.

---

## 7. Business details used in the legal pages

Not secret, but easy to get wrong. These appear in the Disclaimer, Privacy Policy and Terms pages.

| Item | Value |
| --- | --- |
| Legal name | Honoring Stories |
| Business type | Sole proprietorship |
| Udyam Registration Number | `UDYAM-MH-18-0422743` |
| Effective date of the policies | 1 September 2026 |
| Clinical record retention | 7 years after active work ends |
| Location | Andheri West, Mumbai |

Two things deliberately left out: no postal address, and no named grievance officer.

**These three pages have not been checked by a lawyer.** Do that before the website goes public.

---

## Quick summary: what to have ready

Before starting a session with an assistant, have these to hand if the work touches them:

- [ ] GitHub username and a Personal Access Token, if publishing
- [ ] The Google account login, if changing the form or approving notes
- [ ] The cal.com login, only if changing the booking link
- [ ] The domain registrar login, only if connecting the domain

You will not need all of them. Most changes to the website need none of them at all.
