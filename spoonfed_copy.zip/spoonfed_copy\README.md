# Honoring Stories website: the spoonfed copy

**Everything you need to rebuild this website exactly, explained from zero.**

Prepared 2026-08-27. Website version: the one Harshita Sarda approved as final.

If you follow this document from top to bottom, you will end up with a website identical to the
approved version. You do not need to know how to code. You need to be able to read, click, and copy
and paste.

---

## Part 1: What you are holding

### 1.1 What this website is

A website for Harshita Sarda, a psychotherapist and clinical supervisor in Andheri West, Mumbai.
It has nine pages: a homepage, an about page, three pages describing the work she offers, a
community page, and three legal pages.

### 1.2 What is in this folder

```
spoonfed_copy/
│
├── README.md                    <-- you are reading this
├── SETUP_CHECKLIST.md           <-- the things only you can provide
├── STRUCTURE.md                 <-- how every file relates to every other file
│
├── website/                     <-- THE ACTUAL WEBSITE. This is what gets published.
│   ├── index.html
│   ├── about.html
│   ├── psychotherapy.html
│   ├── supervision.html
│   ├── corporates.html
│   ├── community.html
│   ├── disclaimer.html
│   ├── privacy-policy.html
│   ├── terms-and-conditions.html
│   ├── serve.ps1                <-- helper for viewing the site on your own computer
│   └── assets/                  <-- every picture the website uses
│
└── reference/
    └── WEBSITE_INSTRUCTIONS.md  <-- the long, complete history and reasoning
```

**The only folder that gets published is `website/`.** The other files are notes for you and for
whoever works on this next.

### 1.3 The single most important thing to understand

There is **no separate CSS file and no separate JavaScript file.** If you have seen other websites,
you may expect a `style.css` or a `script.js`. There isn't one here, and that is on purpose.

Every one of the nine pages is a **single self-contained file**. Open `index.html` in a text editor
and you will find three things stacked inside it:

1. The **HTML**, which is the words and the structure.
2. The **CSS**, which is the colours, fonts and layout. It sits inside a `<style>` block near the
   top of the file.
3. The **JavaScript**, which is the movement and interactivity. It sits inside a `<script>` block
   near the bottom of the file.

**What this means in practice:** if you change the menu at the top of the page, you must make that
same change **nine times**, once in every page file. There is no shared file that does it for all
of them. This is the single most common way this website gets broken. It is covered again in
Part 6.

### 1.4 Why it was built this way

Because the site is going to be moved into WordPress later. Self-contained files with no build
tools, no frameworks and no server code are the easiest thing in the world to move. Nothing has to
be un-picked first.

The trade-off is the nine-copies problem above. That trade was made deliberately, with eyes open.

---

## Part 2: Look at the website on your own computer

Do this first. It takes two minutes and proves everything works before you try to publish anything.

### Method A: the simplest possible way

1. Open the `website` folder.
2. Double-click `index.html`.
3. Your web browser opens and the website appears.

**This works for everything except one thing.** On the Community page, the section called "Shared
Ways of Coping" will show a message saying the notes could not be loaded. That is not a fault. Your
browser blocks that one feature when a page is opened straight from a folder rather than served
properly. Use Method B if you need to check that section.

### Method B: the proper way

1. Open the `website` folder.
2. Hold **Shift**, right-click on an empty part of the folder, and choose **Open PowerShell window
   here** (on some computers it says **Open Terminal here**).
3. Copy this line, paste it into the black window, and press **Enter**:

   ```
   powershell -NoProfile -ExecutionPolicy Bypass -File serve.ps1
   ```

4. It will print `serving ... on http://localhost:8080/`.
5. Open your browser and go to: **http://localhost:8080/index.html**
6. When you are finished, click on the black window and press **Ctrl + C** to stop it.

Leave the black window open the whole time you are looking at the site. Closing it switches the
site off.

**Why this file exists:** the normal way to do this uses a program called Node or Python. Harshita's
computer has neither installed. `serve.ps1` does the same job using something already built into
Windows, so nothing has to be installed.

---

## Part 3: Put the website on the internet

The website is nine files and some pictures. It has no database and no server code, which means it
can be hosted almost anywhere, most of it free.

### Option 1: GitHub Pages (free, recommended to start)

1. Go to **github.com** and sign in. If you do not have an account, create one; it is free.
2. Click the **+** in the top right, then **New repository**.
3. Give it a name, for example `honoringstories`. Choose **Public**. Click **Create repository**.
4. On the next page click **uploading an existing file**.
5. Open your `website` folder. Select **everything inside it**, including the `assets` folder.
   Drag it all onto the GitHub page.
6. Scroll down and click **Commit changes**.
7. Click the **Settings** tab at the top of the repository.
8. In the left menu, click **Pages**.
9. Under "Branch", choose **main**, leave the folder as **/ (root)**, and click **Save**.
10. Wait about two minutes, then refresh that page. It will show your web address, something like
    `https://yourname.github.io/honoringstories/`.

**Important:** upload the *contents* of the `website` folder, not the folder itself. If you upload
the folder, every address gains an extra `/website/` in the middle and the pictures break.

### Option 2: Netlify (free, easiest of all)

1. Go to **netlify.com** and sign up.
2. Look for the box that says **Drag and drop your site output folder here**.
3. Drag the whole `website` folder onto it.
4. It gives you a working web address within about thirty seconds.

### Option 3: Your own domain, honoringstories.com

Whichever of the two options above you choose, both let you attach your own domain name. Look for
**Custom domain** in the settings. You will need the login for wherever the domain was purchased,
so you can point it at the host. See `SETUP_CHECKLIST.md` item 6.

### Option 4: WordPress

This is the eventual plan and it is a bigger job. The short version: each page's content becomes a
WordPress page, and the CSS from inside the `<style>` blocks moves into the theme. Do not attempt
this without help. The reasoning and the traps are written up in `reference/WEBSITE_INSTRUCTIONS.md`.

---

## Part 4: The things only you can provide

Some parts of the website connect to accounts that belong to Harshita. **Those connections are not
included in this folder and cannot be**, because they would let anyone who downloads it act as her.

The full list, with instructions for getting each one, is in **`SETUP_CHECKLIST.md`**. Read it
before you change anything that touches the booking button, the contact links, or the Community
page.

The short version of what is already working and needs nothing from you:

- The booking button, the email links, and the WhatsApp links are already filled in and working.
- The Community page submission form is already connected and working.

The short version of what you will eventually need:

- A GitHub account, if you want to publish the site yourself.
- Access to Harshita's Google account, if you ever need to change the questions on the coping
  notes form or approve new notes.

---

## Part 5: Working with an AI on this website

If you open this folder with an AI coding assistant such as Claude Code, this is how to start.

### 5.1 The first thing to say

Copy and paste this:

> Read README.md, STRUCTURE.md, SETUP_CHECKLIST.md and reference/WEBSITE_INSTRUCTIONS.md before
> doing anything. This website is a frozen, approved version. Change only exactly what I ask you to
> change, and nothing else. Before you make any change, tell me what you are about to do and which
> files it touches. If something I ask for would break something documented in those files, tell me
> before you do it, not after.

### 5.2 What a good AI will ask you for, and when

A well-behaved assistant should stop and ask, rather than guess. Here is what it will ask and how
you answer. Every one of these is explained step by step in `SETUP_CHECKLIST.md`.

| When you ask for | It should ask you for | Where you get it |
| --- | --- | --- |
| "Publish the website" | Your GitHub username, and whether the repository exists yet | github.com, your profile |
| "Change the booking link" | The new cal.com link | cal.com, Event Types, copy link |
| "Change the coping notes question" | Nothing; but warn you it will break the submission box | See checklist item 4 |
| "Approve a new coping note" | Nothing from a file; you do it in the Google Sheet | See checklist item 4 |
| "Add a new picture" | The picture file, and which page and position | Put it in `website/assets/` |
| "Change the phone number or email" | The new one | Yours |
| "Build the admin page for coping responses" | It should refuse on a plain website and explain why | See checklist item 5 |

### 5.3 Words to be careful with

Do not say "clean this up", "modernise it", "make it better", or "fix the formatting". Those
invite an assistant to change things nobody asked about. Ask for one specific change at a time and
say what it should look like afterwards.

---

## Part 6: Rules that must not be broken

These are not style preferences. Each one was learned by something going wrong.

### Rule 1: Never use an em dash

An em dash is the long dash: the character between "word" and "word" that is longer than a hyphen.
It must not appear anywhere: not in the visible words, not in a code comment, not in the
description of a picture, not in these notes. Use a comma, a full stop, or rewrite the sentence.

To check, search the files for the character. Zero results is correct.

### Rule 2: A change to the menu or the footer must be made nine times

The menu at the top, the footer at the bottom, the floating green WhatsApp button, and the little
dots down the right-hand edge appear on **all nine pages**, and each page has its own copy. Change
one, you must change all nine, then check all nine.

**There is a trap here.** `index.html` is written in a different style from the other eight. The
other eight write each styling rule on one line. `index.html` spreads them over several lines. So a
find-and-replace that works on the other eight will **silently skip index.html** and you will not
get an error. You will just have a homepage that looks different from every other page. This has
already happened once.

### Rule 3: The pictures are prepared, not raw

Every illustration was processed before going in: its background was either recoloured to exactly
match the page, or removed completely. If you drop in a raw picture straight from wherever it came
from, you will see a faint rectangle around it, because its background will be very slightly the
wrong shade of cream. `reference/WEBSITE_INSTRUCTIONS.md` explains how the processing is done.

### Rule 4: No prices on the homepage

Prices belong only on the Psychotherapy and Supervision pages. The organisations page has no prices
at all, by explicit instruction.

### Rule 5: Do not change things you were not asked to change

This version is approved and frozen. Several things in the code look wrong and are deliberate; they
have comments next to them explaining why. If something looks like a mistake, read the comment and
check the "already tried and rejected" table in `reference/WEBSITE_INSTRUCTIONS.md` before touching
it. Ten separate things in this website were built, shown, rejected, and removed. They should not
come back by accident.

---

## Part 7: If something looks broken

| What you see | What it usually means | What to do |
| --- | --- | --- |
| Fonts look wrong, like an old newspaper | The Google Fonts link failed to load | Check your internet. If it persists, check the font link at the top of the file has not been damaged |
| Pictures are missing, broken icons | Files were uploaded without the `assets` folder, or the folder was renamed | Re-upload, keeping `assets` exactly where it is and spelled the same way |
| Community notes say "could not be loaded" | You opened the file directly instead of using a server | Use Part 2, Method B |
| Community notes say "no notes have been shared yet" | Correct behaviour when nothing has been approved yet | Approve one in the Google Sheet, then wait five minutes |
| A newly approved note does not appear | Google holds the old copy for about five minutes | Wait, then refresh |
| The homepage looks different from the other pages | A change was made to eight pages and missed `index.html` | See Rule 2 |
| A picture has a faint rectangle around it | Its background is not exactly the page colour | See Rule 3 |
| Text changes but nothing happens on screen | Your browser is showing a saved copy | Press **Ctrl + Shift + R** |

---

## Part 8: The technical summary, for whoever wants it

- **Type of website:** static. Nine hand-written HTML files. No server code, no database.
- **Build step:** none. What you see in the folder is exactly what gets published.
- **Frameworks:** none. No React, no Vue, no Bootstrap, no jQuery.
- **Package manager:** none. There is no `package.json` and nothing to install.
- **CSS:** written by hand, inside a `<style>` block in each page. Uses CSS custom properties for
  the colour palette, CSS Grid and Flexbox for layout, and `mask-image` for the soft photo edges.
- **JavaScript:** written by hand, plain browser JavaScript, inside a `<script>` block in each
  page. No libraries. Used for the mobile menu, scroll animations, the testimonials carousel, the
  counting numbers, the FAQ accordions, the collapsible panel, the word counter, and reading the
  published coping notes.
- **Fonts:** Cormorant Garamond and Inter, loaded from Google Fonts. The only external stylesheet.
- **Colour palette:** deep purple `#5B2E6B`, purple `#7A4D8F`, soft purple `#B295C4`, rose
  `#D96A9C`, soft rose `#F2C5D5`, cream `#F8F1E4`, warm cream `#FDFAF2`, charcoal `#2B1E2F`.
- **Responsive:** yes, single column on phones, multi-column from 768px and 900px upward.
- **Accessibility:** semantic headings, alt text on every image, `aria-expanded` on collapsible
  controls, keyboard-reachable menus, and a reduced-motion rule that switches animation off for
  anyone whose device asks for it.

---

## Where to go next

- **`SETUP_CHECKLIST.md`** if you need to connect an account or change a link.
- **`STRUCTURE.md`** if you want to know which file does what and what depends on what.
- **`reference/WEBSITE_INSTRUCTIONS.md`** if you want the full history: every decision, why it was
  made, what was tried and rejected, and every piece of content.
